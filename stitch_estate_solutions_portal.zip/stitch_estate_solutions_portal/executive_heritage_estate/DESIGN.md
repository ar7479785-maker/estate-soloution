---
name: Executive Heritage Estate
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#45464c'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#575e70'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#141b2b'
  on-primary-container: '#7d8497'
  inverse-primary: '#c0c6db'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#181c24'
  on-tertiary-container: '#80848e'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce2f7'
  primary-fixed-dim: '#c0c6db'
  on-primary-fixed: '#141b2b'
  on-primary-fixed-variant: '#404758'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#dfe2ee'
  tertiary-fixed-dim: '#c3c6d2'
  on-tertiary-fixed: '#181c24'
  on-tertiary-fixed-variant: '#434750'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
  luxe-gold-light: '#DFBA73'
  luxe-gold-deep: '#9E7B35'
  slate-black: '#0B0F17'
  charcoal-border: '#E5E7EB'
  dark-surface: '#161F30'
  dark-border: '#283548'
  ivory-base: '#FCFCFD'
typography:
  display-xl:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 68px
    letterSpacing: -0.02em
  display-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 38px
    fontWeight: '600'
    lineHeight: 46px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style

This design system embodies high-tier real estate consulting, private wealth advisory, and architectural prestige tailored for high-net-worth investors and diaspora buyers in DHA Bahawalpur. The aesthetic fuses Modern Architectural Luxury with Heritage Editorial refinement. 

The visual narrative balances authoritative weight with delicate craftsmanship: deep obsidian backdrops, sharp tailored structural lines, and warm metallic accents reminiscent of polished brass and brushed gold. It establishes an atmosphere of discretion, verified institutional credibility, and bespoke concierge service. Every component feels measured, intentional, and enduring—rejecting transient web trends in favor of structural clarity, generous proportioning, and tactile prestige.

## Colors

The color architecture is anchored by deep matte slate black (`#111827`, `#0B0F17`) and accented by calibrated luxe golds (`#C5A059`, `#DFBA73`). Primary backgrounds default to an airy, warm ivory-white (`#F8F9FA` and `#FCFCFD`) for effortless reading of property dossiers, contracts, and analytical masterplans, while executive zones (such as hero showcases, private listing modals, and footer chambers) switch gracefully into saturated obsidian themes.

Gold is applied with surgical restraint—reserved for active tab indicators, exclusive tier pill badges, boundary markers, and primary call-to-action interactions. Dark slate provides foundational structural grounding, ensuring typography maintains uncompromising contrast against clean light surfaces.

## Typography

The typographic hierarchy pairs the editorial authority of Playfair Display with the clean geometric ergonomics of Plus Jakarta Sans. 

Playfair Display commands high-level narrative titles, sector distinctions, and major pricing figures, conveying legacy and architectural refinement. Plus Jakarta Sans handles transactional telemetry, filtering chips, dimensional blueprints, body documentation, and form interfaces. All label and overline tiers apply a deliberate uppercase letter spacing (`+0.04em` to `+0.08em`) to mirror executive architectural blueprints.

## Layout & Spacing

A 12-column fluid grid system with controlled maximum page constraints (`1400px`) maintains architectural balance on ultra-wide viewports. Margins are generous to ensure listings and developmental sector layouts breathe with institutional confidence.

Desktop breakpoints preserve rhythmic vertical modules (`space-2xl` between macro divisions), while tablet and mobile breakpoints compress gutters down to `1rem` and canvas margins to `1.25rem`. Content reflow maintains continuous vertical alignment, aligning card outlines strictly along primary structural columns without staggered disruptions.

## Elevation & Depth

Visual depth is achieved through structural crisp outlines, micro-delimiters, and restrained ambient lighting rather than heavy drop shadows.

1. **Surface Tiers**: Standard cards rest on `#FFFFFF` bordered by fine 1px strokes of `#E5E7EB`. In dark-themed blocks or executive modals, cards utilize `#161F30` framed with 1px `#283548` or 1px subtle gold hairline borders (`rgba(197, 160, 89, 0.25)`).
2. **Ambient Elevation**: Interactive overlays and elevated property dossiers project a subtle, warm-tinted shadow (`0 12px 32px -4px rgba(11, 15, 23, 0.08)` on light mode, `0 16px 40px -8px rgba(0, 0, 0, 0.45)` on dark panels).
3. **Architectural Hairlines**: Thin vertical dividers (`1px` width) separate meta indicators (such as marla/kanal surface area, sector phase, and bed counts) replicating classical draftsman layouts.

## Shapes

The system relies on an intentional architectural geometry: subtle 4px corner radii (`0.25rem`, Level 1). 

Avoid sweeping, pill-like circular forms in favor of clean, tailored edges that convey permanence, stone foundations, and structural framing. Inner card assets (e.g., plot masterplans, drone photography, and floor layouts) retain precision 4px corner rounds to blend into their enclosing structural lines seamlessly.

## Components

### Buttons
- **Primary**: Solid matte slate `#111827` background, ivory text, 1px gold border edge (`#C5A059`), subtle hover lift with gold glow transition (`box-shadow: 0 4px 14px rgba(197, 160, 89, 0.25)`).
- **Secondary / Luxe**: Rich gold gradient or solid `#C5A059` with slate black text (`#0B0F17`) for high-intent conversions (e.g., "Schedule Private Viewing", "Book VIP Consultation").
- **Outline**: Clean transparent fill with 1px border in `#111827` (or `#DFBA73` on dark surfaces) and uppercase tracking.

### Cards
- **Property Listing Cards**: High-definition architectural frame with a top badge container, a structured 1px border, 12px internal padding, serif pricing display, and a dedicated horizontal metric bar (Marla/Kanal, Sector, Possession Status) delimited by fine hairlines.
- **Executive Agent Cards**: Portrait framing featuring dark slate backdrops, direct WhatsApp/call touchpoints, and gold verification badges.

### Chips & Badges
- **Status Badges**: Semi-translucent gold tint (`rgba(197, 160, 89, 0.12)`) with deep gold text (`#9E7B35`) and sharp 2px radius borders for attributes such as "Possession Ready", "Sector A Premium", or "Commercial Direct".

### Input Fields & Selectors
- **Forms**: Clean ivory-white or deep slate base with 1px `#E5E7EB` border, shifting to a solid 1.5px `#C5A059` border upon focus. Labels are rendered in crisp, small uppercase sans-serif with subtle letter spacing.

### Checkboxes & Radio Controls
- **Toggles**: Squared-off 4px corner styling with `#C5A059` check fills and dark slate checkmark glyphs, dispensing with rounded bubble designs.

### Sector & Phase Visualizer
- **Interactive Sector Tabs**: Horizontal tab bar featuring serif category titles, gold under-line accents on selection, and live plot availability counter chips.